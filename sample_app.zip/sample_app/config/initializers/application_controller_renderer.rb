# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ce692a0f5c5acfddeff3e2fbd751a198ee50a90ab853b7bb097ab4a05a5158430902524535d2fec989cffac68eb0c99f71a6da77e03ed88ea566e04ee5026b03'